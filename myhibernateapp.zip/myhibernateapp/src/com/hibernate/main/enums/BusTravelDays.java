package com.hibernate.main.enums;

public enum BusTravelDays {
	MONDAY, TUESDAY, WEDNESDAY,THURSDAY,FRIDAY, SATURDAY, SUNDAY 
}