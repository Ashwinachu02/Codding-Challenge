package com.hibernate.main.enums;

public enum RoleType {
	
	CUSTOMER,EXECUTIVE,SERVICE_PROVIDER

}
